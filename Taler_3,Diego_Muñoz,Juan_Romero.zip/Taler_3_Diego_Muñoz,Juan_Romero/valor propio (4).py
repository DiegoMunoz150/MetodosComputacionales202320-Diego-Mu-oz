import numpy as np
def reduccion (M):
    for i in range (0,M.shape[0]):
        if M[i,i]!=0:
            M[i,:]=M[i,:]/M[i,i]
            for j in range (i+1,M.shape[0]):
                if M[j,i]!=0:
                    M[j,:]=M[j,:]/M[j,i]
                    M[j,:]=M[j,:]-M[i,:]
    return M
def back_substitution(A, b):
    n = np.shape(A)[0]
    x = np.zeros(n)
    for i in range(n-1,-1,-1):
        sum = b[i]
        for j in range(n-1,i,-1):
            sum -= A[i,j]*x[j]
        x[i] = sum/A[i,i]
    return x

F = np.array([[3., 1., -1., 2.],
              [1., -2., 1., 0.],
              [4., -1., 1., 3.]])

F=reduccion(F)
x=F[:,-1]
F=F[:,:-1]
x=back_substitution(F,x)
print(x)
I=np.array([[1.,1.,1.,0.],
            [0.,-8.,10.,0.],
            [4.,-8.,0.,6.]])
I=reduccion(I)
y=I[:,-1]
I=I[:,:-1]
y=back_substitution(I,y)
print(y)
def valor_propio_maximo(M,z):
    for k in range(0,10000):
        q=z/np.sqrt((z[0])**2+(z[1])**2+(z[2])**2)
        z=np.matmul(M,q)
        qt=q.T
        valor=np.matmul(qt,np.matmul(M,q))
    return valor
def valor_propio_minimo(M,z):
    M=np.linalg.inv(M)
    for k in range(0,10000):
        q=z/np.sqrt((z[0])**2+(z[1])**2+(z[2])**2)
        z=np.matmul(M,q)
        qt=q.T
        valor=np.matmul(qt,np.matmul(M,q))
    return valor

def vector_propio(A,vector,valor):
    for i in range(A.shape[0]):
        A[i,i]=A[i,i]-valor
    A=reduccion(A)
    x=back_substitution(A,vector)
    return x
M=np.array([[-2.,1.,0.],
             [1.,-2.,1.],
             [0.,1.,-2.]])
x=[-1.,0.,1.]
vector_prueba=np.array([1.,1.,1.])
valor_maximo=valor_propio_maximo(M, vector_prueba)
valor_minimo=valor_propio_minimo(M, vector_prueba)
vector_maximo=vector_propio(M.copy(),x, valor_maximo)
vector_minimo=vector_propio(M.copy(),x, valor_minimo)
print(valor_maximo,vector_maximo)
print(valor_minimo, vector_minimo)         
            